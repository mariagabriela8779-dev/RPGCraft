# RPG Craft - Minecraft 1.20.1 Fabric

**Um sistema de classes RPG épico criado do zero.**

## Classes Disponíveis

| Classe       | Estilo              | Descrição |
|--------------|---------------------|-----------|
| **Espadachim** | Guerreiro Melee    | Combate corpo a corpo brutal |
| **Artesão**    | Crafter            | Receitas exclusivas e ferramentas lendárias |
| **Arqueiro**   | Ranger             | Tiros precisos e armadilhas |
| **Mago**       | Mágico             | Magias elementais |
| **Mineiro**    | Explorador         | Sorte e visão de minérios |
| **Assassino**  | Stealth            | Críticos, invisibilidade e venenos |

## Como usar

1. Entre no mundo
2. Digite `/rpg select <classe>`  
   Exemplos:
   - `/rpg select espadachim`
   - `/rpg select artesao`
   - `/rpg select mago`
3. Veja suas stats com `/rpg stats`
4. Use `/rpg help` para ver todos os comandos

## Progressão

- Nível de 1 a 100
- Ganha **2 Skill Points** por nível
- XP é ganho de várias fontes (em expansão)

## Como compilar

```bash
./gradlew build
```

O arquivo `.jar` ficará em `build/libs/`

## Próximos passos (já planejados)

- Tela gráfica de seleção de classe (já existe o código base)
- Árvore de skills por classe
- Habilidades ativas (teclas)
- Itens exclusivos por classe
- Sistema de Evolução (Ex: Espadachim → Cavaleiro → Senhor da Guerra)
- Quests e dungeons

---

Criado com 🔥 por Grok
