package com.rpgcraft.classsystem;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public enum PlayerClass {
    NONE("Nenhuma", "none", Formatting.GRAY, "Você ainda não escolheu uma classe."),
    
    ESPADACHIM("Espadachim", "espadachim", Formatting.RED, 
        "Mestre das lâminas. Combate corpo a corpo brutal, combos devastadores e fúria de batalha."),
    
    ARTESAO("Artesão", "artesao", Formatting.GOLD, 
        "Gênio da criação. Receitas exclusivas, ferramentas lendárias e forja aprimorada."),
    
    ARQUEIRO("Arqueiro", "arqueiro", Formatting.GREEN, 
        "Caçador das distâncias. Tiros precisos, armadilhas e rastreamento mortal."),
    
    MAGO("Mago", "mago", Formatting.LIGHT_PURPLE, 
        "Controlador dos elementos. Magias poderosas de fogo, gelo e relâmpago."),
    
    MINEIRO("Mineiro", "mineiro", Formatting.AQUA, 
        "Senhor das profundezas. Visão de minérios, sorte elevada e veios raros."),
    
    ASSASSINO("Assassino", "assassino", Formatting.DARK_GRAY, 
        "Sombra silenciosa. Críticos letais, invisibilidade e venenos mortais.");

    private final String displayName;
    private final String id;
    private final Formatting color;
    private final String description;

    PlayerClass(String displayName, String id, Formatting color, String description) {
        this.displayName = displayName;
        this.id = id;
        this.color = color;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getId() {
        return id;
    }

    public Formatting getColor() {
        return color;
    }

    public String getDescription() {
        return description;
    }

    public Text getStyledName() {
        return Text.literal(displayName).formatted(color, Formatting.BOLD);
    }

    public static PlayerClass fromId(String id) {
        for (PlayerClass pc : values()) {
            if (pc.id.equalsIgnoreCase(id)) {
                return pc;
            }
        }
        return NONE;
    }
}
