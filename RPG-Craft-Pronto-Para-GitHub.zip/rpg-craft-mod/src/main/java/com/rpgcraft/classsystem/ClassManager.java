package com.rpgcraft.classsystem;

import com.rpgcraft.data.PlayerData;
import com.rpgcraft.data.PlayerDataHolder;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class ClassManager {

    public static void init() {
        // Placeholder for future skill registrations
    }

    public static PlayerData getData(PlayerEntity player) {
        if (player instanceof PlayerDataHolder holder) {
            return holder.rpgcraft$getData();
        }
        return PlayerData.createDefault();
    }

    public static void setClass(ServerPlayerEntity player, PlayerClass newClass) {
        PlayerData data = getData(player);
        data.setPlayerClass(newClass);
        data.setLevel(1);
        data.setSkillPoints(3); // pontos iniciais
        data.setHasChosenClass(true);

        player.sendMessage(Text.literal("§6§l✦ Classe escolhida: ")
                .append(newClass.getStyledName())
                .append(Text.literal(" §7- Que sua jornada comece!")), false);

        // Aplicar bônus iniciais
        applyClassBonuses(player, newClass);
    }

    private static void applyClassBonuses(ServerPlayerEntity player, PlayerClass playerClass) {
        switch (playerClass) {
            case ESPADACHIM -> {
                player.sendMessage(Text.literal("§c+ Força de combate e resistência aumentadas!"), false);
            }
            case ARTESAO -> {
                player.sendMessage(Text.literal("§6+ Habilidade de crafting superior desbloqueada!"), false);
            }
            case ARQUEIRO -> {
                player.sendMessage(Text.literal("§a+ Precisão e agilidade aprimoradas!"), false);
            }
            case MAGO -> {
                player.sendMessage(Text.literal("§d+ Conexão com os elementos estabelecida!"), false);
            }
            case MINEIRO -> {
                player.sendMessage(Text.literal("§b+ Sorte de mineração e visão de veios!"), false);
            }
            case ASSASSINO -> {
                player.sendMessage(Text.literal("§8+ Sombra e veneno agora te acompanham!"), false);
            }
            default -> {}
        }
    }

    public static void addXp(ServerPlayerEntity player, int amount) {
        PlayerData data = getData(player);
        if (!data.hasChosenClass()) return;

        int oldLevel = data.getLevel();
        data.addExperience(amount);

        if (data.getLevel() > oldLevel) {
            player.sendMessage(Text.literal("§a§l⬆ LEVEL UP! ")
                    .append(Text.literal("Nível " + data.getLevel()).formatted(Formatting.GOLD, Formatting.BOLD))
                    .append(Text.literal(" §7(+2 Skill Points)")), false);
        }
    }
}
